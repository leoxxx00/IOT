import sqlite3
import time
from datetime import datetime
from fastapi import FastAPI
from pydantic import BaseModel, Field
from common import data, json

app = FastAPI(title="SolarMind local test backend")


class Reading(BaseModel):
    site_id: str
    timestamp: datetime
    pv_power_w: float = Field(ge=0)
    load_power_w: float = Field(ge=0)
    grid_power_w: float
    battery_power_w: float
    battery_soc_pct: float = Field(ge=0, le=100)


@app.post("/readings")
def save(reading: Reading):
    with sqlite3.connect(data/"backend.db") as db:
        db.execute("CREATE TABLE IF NOT EXISTS readings(site TEXT, stamp TEXT, payload TEXT, PRIMARY KEY(site,stamp))")
        db.execute("INSERT OR IGNORE INTO readings VALUES(?,?,?)",
                   (reading.site_id, reading.timestamp.isoformat(), reading.model_dump_json()))
    return {"accepted": True}


@app.get("/weather")
def weather():
    try:
        observation = json.loads((data/"weather.json").read_text())
    except FileNotFoundError:
        return {"source": "daily profile", "weather_available": False}
    fresh = 0 <= time.time()-observation["observed_epoch"] < 3600
    return {**observation, "weather_available": fresh, "source": "Open-Meteo" if fresh else "daily profile"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8010)
